export { default as component } from "../../../src/routes/+layout.svelte";
export const server = true;