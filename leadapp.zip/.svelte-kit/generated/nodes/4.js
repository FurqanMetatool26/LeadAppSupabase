export { default as component } from "../../../src/routes/register/+page.svelte";
export const server = true;