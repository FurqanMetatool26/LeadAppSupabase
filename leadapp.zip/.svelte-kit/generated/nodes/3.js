export { default as component } from "../../../src/routes/login/+page.svelte";
export const server = true;