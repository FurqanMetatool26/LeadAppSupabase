// @ts-nocheck
import { getServerSession } from "@supabase/auth-helpers-sveltekit"
import type { LayoutServerLoad } from "./$types"

export const load = async (event: Parameters<LayoutServerLoad>[0]) => {
	console.log("Ran layout load")
	return {
		session: await getServerSession(event),
	}
}
